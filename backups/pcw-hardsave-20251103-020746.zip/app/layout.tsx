import NavClientOnly from "@/components/NavClientOnly";
import AppKitInit from "../components/AppKitInit";
import "./globals.css";
import type { Metadata } from "next";

import Providers from "./providers";

import Nav from "../components/Nav";
import Footer from "../components/Footer";
import SocialDock from "../components/SocialDock";
import ContactDock from "../components/ContactDock";

export const metadata: Metadata = {
  title: "PCW – Swap",
  description: "Power Crypto World",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="theme-future">
        <div id="noise-overlay" />
        <Providers>
          <NavClientOnly />
          <main
            className="mx-auto max-w-6xl px-5 py-10"
            style={{ paddingTop: 64, paddingBottom: 96 }}
          >
            <AppKitInit />
        {children}
          </main>
          <Footer />
          <SocialDock />
          <ContactDock />
        </Providers>
      </body>
    </html>
  );
}
